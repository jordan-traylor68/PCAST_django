import re
from django.core.management.base import BaseCommand, CommandError
from documents.models import *
import os
import requests
import json

class Command(BaseCommand):
	help = 'walks the iiif manifest link attached to each document and records the page images that we get from that manifest'
	def handle(self, *args, **options):
		
		#pull all our documents
		docs=Document.objects.all()
		#https://iiif.quartexcollections.com/rice/iiif/4c4edf2b-8dd9-4cd3-8148-ec7b0b8b842e/manifest
		for doc in docs:
			quartex_uid=doc.quartex_uid
			manifest_url="https://iiif.quartexcollections.com/rice/iiif/%s/manifest" %quartex_uid
			print("MANIFEST-->",manifest_url)
			r = requests.get(manifest_url)
			if r.status_code!=200:
				print("uh-oh",r.status_code)
				exit()
			else:
				manifest_json=r.text
				manifest_dict=json.loads(manifest_json)
# 				print(manifest_dict['metadata'],'\n-----------')
				#we want these:
				#https://iiif.quartexcollections.com/rice/iiif/39ac2eb7-eaec-42fa-88a4-dbdd3b1cd18e/full/500,500/0/default.jpg
				#https://iiif.quartexcollections.com/rice/iiif/39ac2eb7-eaec-42fa-88a4-dbdd3b1cd18e/full/full/0/default.jpg
				#they live in here: sequences:canvases ARRAY resource:id
				sequences=manifest_dict['sequences']
				if len(sequences)>1:
					print("WARNING! MULTIPLE SEQUENCES. ONLY DOING THE FIRST")
				sequence=sequences[0]
				canvases=sequence['canvases']
				pagenumber=1
				for canvas in canvases:
					image=canvas['images']
					if len(image)>1:
						print("WARNING! MULTIPLE IMAGES ON THIS CANVAS. ONLY DOING THE FIRST")
					image=image[0]
					image_link=image['resource']['@id']
					
					print("IMAGE LINK-->",image_link)
					#https://iiif.quartexcollections.com/rice/iiif/3fe12e23-d2d5-476c-8341-6137b1edd0ac/full/full/0/default.jpg
					iiif_hash=re.search('[a-z|0-9]+-[a-z|0-9]+-[a-z|0-9]+-[a-z|0-9]+-[a-z|0-9]+',image_link).group(0)
					print(iiif_hash)
					
					page,page_isnew=Pages.objects.get_or_create(
						quartex_image_iiif_hash=iiif_hash,
						order=pagenumber,
						document=doc
					)
					pagenumber+=1
					
					# 
# class Pages(models.Model):
# 	quartex_image_iiif_hash=models.CharField(max_length=36,null=False,blank=False,unique=True)
# 	document=models.ForeignKey(Document,null=False,blank=False,on_delete=models.CASCADE)
# 	order=models.IntegerField(null=False,blank=False)
# 	class Meta:
# 		unique_together = ["order", "document"]